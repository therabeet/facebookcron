/*
SQLyog Ultimate v8.82 
MySQL - 5.5.8-log : Database - contentio
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*Table structure for table `cio_facebook_url` */

DROP TABLE IF EXISTS `cio_facebook_url`;

CREATE TABLE `cio_facebook_url` (
  `facebook_url_id` int(22) NOT NULL AUTO_INCREMENT,
  `facebook_url_link` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `facebook_url_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `facebook_user_id` int(22) NOT NULL,
  `facebook_url_add_date` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `facebook_url_edit_date` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`facebook_url_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
